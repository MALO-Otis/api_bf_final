import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../vente/models/vente_models.dart';

/// 🛍️ FORMULAIRE MODERNE DE VENTE
class VenteFormeModerne extends StatefulWidget {
  final List<Prelevement> prelevements;
  final VoidCallback onVenteEnregistree;

  const VenteFormeModerne({
    super.key,
    required this.prelevements,
    required this.onVenteEnregistree,
  });

  @override
  State<VenteFormeModerne> createState() => _VenteFormeModerneState();
}

class _VenteFormeModerneState extends State<VenteFormeModerne> {
  final _formKey = GlobalKey<FormState>();
  final _clientController = TextEditingController();
  final _observationsController = TextEditingController();

  Prelevement? _prelevementSelectionne;
  String _modePaiement = 'especes';
  bool _isLoading = false;

  @override
  void dispose() {
    _clientController.dispose();
    _observationsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Container(
        constraints: const BoxConstraints(maxWidth: 500, maxHeight: 600),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF3B82F6), Color(0xFF1D4ED8)],
                ),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.point_of_sale,
                      color: Colors.white, size: 28),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Text(
                      'Nouvelle Vente',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Get.back(),
                    icon: const Icon(Icons.close, color: Colors.white),
                  ),
                ],
              ),
            ),

            // Contenu
            Flexible(
              child: Form(
                key: _formKey,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      // Sélection du prélèvement
                      DropdownButtonFormField<Prelevement>(
                        value: _prelevementSelectionne,
                        decoration: InputDecoration(
                          labelText: 'Prélèvement à vendre',
                          prefixIcon: const Icon(Icons.shopping_bag),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        items: widget.prelevements.map((prelevement) {
                          return DropdownMenuItem(
                            value: prelevement,
                            child: Text(
                                '${prelevement.id.split('_').last} (${prelevement.produits.length} produits)'),
                          );
                        }).toList(),
                        onChanged: (value) =>
                            setState(() => _prelevementSelectionne = value),
                        validator: (value) => value == null
                            ? 'Sélectionnez un prélèvement'
                            : null,
                      ),

                      const SizedBox(height: 16),

                      // Nom du client
                      TextFormField(
                        controller: _clientController,
                        decoration: InputDecoration(
                          labelText: 'Nom du client',
                          prefixIcon: const Icon(Icons.person),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.trim().isEmpty) {
                            return 'Entrez le nom du client';
                          }
                          return null;
                        },
                      ),

                      const SizedBox(height: 16),

                      // Mode de paiement
                      DropdownButtonFormField<String>(
                        value: _modePaiement,
                        decoration: InputDecoration(
                          labelText: 'Mode de paiement',
                          prefixIcon: const Icon(Icons.payment),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        items: const [
                          DropdownMenuItem(
                              value: 'especes', child: Text('Espèces')),
                          DropdownMenuItem(
                              value: 'mobile_money',
                              child: Text('Mobile Money')),
                          DropdownMenuItem(
                              value: 'virement',
                              child: Text('Virement bancaire')),
                        ],
                        onChanged: (value) =>
                            setState(() => _modePaiement = value!),
                      ),

                      const SizedBox(height: 16),

                      // Observations
                      TextFormField(
                        controller: _observationsController,
                        maxLines: 3,
                        decoration: InputDecoration(
                          labelText: 'Observations (optionnel)',
                          prefixIcon: const Icon(Icons.note),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),

                      if (_prelevementSelectionne != null) ...[
                        const SizedBox(height: 20),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.blue.shade50,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Détails de la vente',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue.shade800,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                  '${_prelevementSelectionne!.produits.length} produits'),
                              Text(
                                'Valeur totale: ${VenteUtils.formatPrix(_prelevementSelectionne!.valeurTotale)}',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue.shade700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),

            // Actions
            Container(
              padding: const EdgeInsets.all(24),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Get.back(),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text('Annuler'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _enregistrerVente,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF3B82F6),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            )
                          : const Text('Enregistrer'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _enregistrerVente() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      // TODO: Enregistrer la vente dans la base de données
      await Future.delayed(const Duration(seconds: 1)); // Simulation

      Get.snackbar(
        'Succès',
        'Vente enregistrée avec succès !',
        backgroundColor: Colors.green,
        colorText: Colors.white,
        snackPosition: SnackPosition.TOP,
      );

      widget.onVenteEnregistree();
    } catch (e) {
      Get.snackbar(
        'Erreur',
        'Impossible d\'enregistrer la vente: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }
}
