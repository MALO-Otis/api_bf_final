import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../vente/models/vente_models.dart';

/// 🎴 CARTE DÉTAILLÉE DE PRÉLÈVEMENT
class PrelevementDetailCard extends StatelessWidget {
  final Prelevement prelevement;
  final Function(Prelevement, String) onAction;

  const PrelevementDetailCard({
    super.key,
    required this.prelevement,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    final statusColor = _getStatusColor(prelevement.statut);
    final statusLabel = _getStatusLabel(prelevement.statut);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isSmall = constraints.maxWidth < 600;

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.08),
                blurRadius: 15,
                offset: const Offset(0, 6),
              ),
            ],
            border: Border.all(
              color: statusColor.withOpacity(0.2),
              width: 1.5,
            ),
          ),
          child: Column(
            children: [
              // Header avec statut
              _buildHeader(statusColor, statusLabel, isSmall),

              // Contenu principal
              _buildContent(isSmall),

              // Actions
              if (prelevement.statut == StatutPrelevement.enCours)
                _buildActions(isSmall),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeader(Color statusColor, String statusLabel, bool isSmall) {
    return Container(
      padding: EdgeInsets.all(isSmall ? 16 : 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            statusColor.withOpacity(0.1),
            statusColor.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.15),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: statusColor.withOpacity(0.2),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Icon(
              Icons.shopping_bag,
              color: statusColor,
              size: isSmall ? 24 : 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Prélèvement ${prelevement.id.split('_').last}',
                        style: TextStyle(
                          fontSize: isSmall ? 16 : 18,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1F2937),
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: statusColor,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: statusColor.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Text(
                        statusLabel,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(
                      Icons.access_time,
                      size: 16,
                      color: Colors.grey.shade600,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      DateFormat('dd/MM/yyyy à HH:mm')
                          .format(prelevement.datePrelevement),
                      style: TextStyle(
                        fontSize: isSmall ? 12 : 14,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.person,
                      size: 16,
                      color: Colors.grey.shade600,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'Par ${prelevement.magazinierNom}',
                      style: TextStyle(
                        fontSize: isSmall ? 12 : 14,
                        color: Colors.grey.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(bool isSmall) {
    return Padding(
      padding: EdgeInsets.all(isSmall ? 16 : 20),
      child: Column(
        children: [
          // Statistiques principales
          Row(
            children: [
              Expanded(
                child: _buildInfoColumn(
                  'Produits',
                  '${prelevement.produits.length}',
                  Icons.inventory_2,
                  const Color(0xFF3B82F6),
                  isSmall,
                ),
              ),
              Container(
                width: 1,
                height: 50,
                color: Colors.grey.shade200,
                margin: const EdgeInsets.symmetric(horizontal: 16),
              ),
              Expanded(
                child: _buildInfoColumn(
                  'Valeur Totale',
                  VenteUtils.formatPrix(prelevement.valeurTotale),
                  Icons.monetization_on,
                  const Color(0xFF10B981),
                  isSmall,
                ),
              ),
              Container(
                width: 1,
                height: 50,
                color: Colors.grey.shade200,
                margin: const EdgeInsets.symmetric(horizontal: 16),
              ),
              Expanded(
                child: _buildInfoColumn(
                  'Quantité',
                  '${prelevement.produits.fold<int>(0, (sum, p) => sum + p.quantitePreleve)}',
                  Icons.scale,
                  const Color(0xFFF59E0B),
                  isSmall,
                ),
              ),
            ],
          ),

          // Aperçu des produits
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.list_alt, size: 18, color: Colors.grey.shade700),
                    const SizedBox(width: 8),
                    Text(
                      'Aperçu des produits',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey.shade700,
                      ),
                    ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => onAction(prelevement, 'details'),
                      child: Text(
                        'Voir tout',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.blue.shade600,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...prelevement.produits
                    .take(3)
                    .map((produit) => Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: Colors.blue.shade400,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  '${produit.typeEmballage} (${produit.quantitePreleve})',
                                  style: const TextStyle(fontSize: 13),
                                ),
                              ),
                              Text(
                                VenteUtils.formatPrix(produit.prixUnitaire *
                                    produit.quantitePreleve),
                                style: const TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ))
                    .toList(),
                if (prelevement.produits.length > 3)
                  Text(
                    '... et ${prelevement.produits.length - 3} autre${prelevement.produits.length - 3 > 1 ? 's' : ''} produit${prelevement.produits.length - 3 > 1 ? 's' : ''}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade600,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
              ],
            ),
          ),

          // Observations si présentes
          if (prelevement.observations != null &&
              prelevement.observations!.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.amber.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.amber.shade200),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline,
                      color: Colors.amber.shade700, size: 20),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Observations',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.amber.shade800,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          prelevement.observations!,
                          style: TextStyle(
                            color: Colors.amber.shade700,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActions(bool isSmall) {
    return Container(
      padding: EdgeInsets.all(isSmall ? 16 : 20),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(20),
          bottomRight: Radius.circular(20),
        ),
      ),
      child: isSmall
          ? Column(
              children: [
                Row(
                  children: [
                    Expanded(
                        child: _buildActionButton('Vendre', Icons.point_of_sale,
                            const Color(0xFF10B981), 'vendre')),
                    const SizedBox(width: 8),
                    Expanded(
                        child: _buildActionButton('Restituer', Icons.undo,
                            const Color(0xFFF59E0B), 'restituer')),
                  ],
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: _buildActionButton('Déclarer Perte', Icons.warning,
                      const Color(0xFFEF4444), 'perte'),
                ),
              ],
            )
          : Row(
              children: [
                Expanded(
                    child: _buildActionButton('Vendre', Icons.point_of_sale,
                        const Color(0xFF10B981), 'vendre')),
                const SizedBox(width: 12),
                Expanded(
                    child: _buildActionButton('Restituer', Icons.undo,
                        const Color(0xFFF59E0B), 'restituer')),
                const SizedBox(width: 12),
                Expanded(
                    child: _buildActionButton('Déclarer Perte', Icons.warning,
                        const Color(0xFFEF4444), 'perte')),
              ],
            ),
    );
  }

  Widget _buildActionButton(
      String label, IconData icon, Color color, String action) {
    return ElevatedButton.icon(
      onPressed: () => onAction(prelevement, action),
      icon: Icon(icon, size: 18),
      label: Text(
        label,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        elevation: 3,
        shadowColor: color.withOpacity(0.3),
      ),
    );
  }

  Widget _buildInfoColumn(
      String label, String value, IconData icon, Color color, bool isSmall) {
    return Column(
      children: [
        Icon(icon, color: color, size: isSmall ? 24 : 28),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: isSmall ? 16 : 18,
            fontWeight: FontWeight.bold,
            color: const Color(0xFF1F2937),
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: isSmall ? 11 : 12,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Color _getStatusColor(StatutPrelevement statut) {
    switch (statut) {
      case StatutPrelevement.enCours:
        return const Color(0xFF3B82F6);
      case StatutPrelevement.partiel:
        return const Color(0xFFF59E0B);
      case StatutPrelevement.termine:
        return const Color(0xFF10B981);
      case StatutPrelevement.annule:
        return const Color(0xFFEF4444);
    }
  }

  String _getStatusLabel(StatutPrelevement statut) {
    switch (statut) {
      case StatutPrelevement.enCours:
        return 'En cours';
      case StatutPrelevement.partiel:
        return 'Partiel';
      case StatutPrelevement.termine:
        return 'Terminé';
      case StatutPrelevement.annule:
        return 'Annulé';
    }
  }
}
