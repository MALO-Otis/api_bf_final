import 'package:get/get.dart';
import '../models/vente_models.dart';
import '../services/vente_service.dart';
import '../models/commercial_models.dart';
import '../services/commercial_service.dart';
import '../../../authentication/user_session.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

/// Controller central pour l'Espace Commercial
/// Gère : prélevements, ventes, restitutions, pertes avec logique rôle/site
class EspaceCommercialController extends GetxController {
  final UserSession _session = Get.find<UserSession>();
  final VenteService _venteService = VenteService();
  final CommercialService _commercialService =
      CommercialService(); // pourra servir pour stats spécifiques

  // Etat réactif
  final RxBool isLoading = false.obs;
  final RxString selectedSite = ''.obs; // admin peut changer
  final RxString search = ''.obs;
  final RxInt currentTab = 0.obs;

  final RxList<Prelevement> prelevements = <Prelevement>[].obs;
  final RxList<Vente> ventes = <Vente>[].obs;
  final RxList<Restitution> restitutions = <Restitution>[].obs;
  final RxList<Perte> pertes = <Perte>[].obs;
  final RxList<ClientLight> clients = <ClientLight>[].obs;
  int get clientsCount => clients.length;

  // Attribution scope (for non-admin)
  final RxSet<String> _attributedKeys =
      <String>{}.obs; // key format: lotId or numeroLot_type_site
  int get attributedLotsCount => _attributedKeys.length;

  // Diagnostics
  DateTime? _lastFullLoad;
  Duration get ageSinceLastLoad => _lastFullLoad == null
      ? Duration.zero
      : DateTime.now().difference(_lastFullLoad!);
  double get valeurStockCommercial => _commercialService.valeurStockTotale;
  List<String> get availableSites => _venteService.sites;
  // Diagnostics vente service counters
  int get ventesFetchCount => _venteService.ventesFetchCount;
  int get restitutionsFetchCount => _venteService.restitutionsFetchCount;
  int get pertesFetchCount => _venteService.pertesFetchCount;
  int get prelevementsFetchCount => _venteService.prelevementsFetchCount;
  int get attributionLotsCount => attributedLotsCount;
  int get clientsLoaded => clients.length;
  // Note: prelevements now intentionally unfiltered by attribution for commercials (site-wide visibility)

  // ================= UTILISATEURS (résolution noms depuis emails) =================
  final Map<String, String> _userDisplayNameCache = {}; // email -> 'Prenom Nom'
  DateTime? _lastUserFetch;
  final Duration _userCacheTtl = const Duration(minutes: 5);
  bool _userFetchInProgress = false;

  String displayNameForEmail(String? email) {
    if (email == null || email.isEmpty) return 'Inconnu';
    return _userDisplayNameCache[email] ??
        email; // fallback email si pas encore résolu
  }

  Future<void> _resolveUserNamesFromData() async {
    // Collect all emails we need (commercialId + magazinierId + validateur + etc.)
    final Set<String> emails = {};
    for (final p in prelevements) {
      emails.add(p.commercialId);
      emails.add(p.magazinierId);
    }
    for (final v in ventes) {
      emails.add(v.commercialId);
    }
    for (final r in restitutions) {
      emails.add(r.commercialId);
    }
    for (final p in pertes) {
      emails.add(p.commercialId);
      if (p.validateurId != null) emails.add(p.validateurId!);
    }

    emails.removeWhere((e) => e.isEmpty);

    // Filter emails already cached & still valid
    if (_lastUserFetch != null &&
        DateTime.now().difference(_lastUserFetch!) < _userCacheTtl) {
      emails.removeWhere((e) => _userDisplayNameCache.containsKey(e));
      if (emails.isEmpty) return; // nothing new to resolve
    }
    if (emails.isEmpty) return;
    if (_userFetchInProgress) return; // avoid duplicate overlapping fetch
    _userFetchInProgress = true;
    try {
      final firestore = FirebaseFirestore.instance;
      // Firestore whereIn limit: 10 entries. We chunk.
      final List<String> all = emails.toList();
      for (int i = 0; i < all.length; i += 10) {
        final chunk = all.sublist(i, i + 10 > all.length ? all.length : i + 10);
        final snap = await firestore
            .collection('utilisateurs')
            .where('email', whereIn: chunk)
            .get();
        for (final doc in snap.docs) {
          final data = doc.data();
          final email = (data['email'] ?? '') as String;
          final prenom = (data['prenom'] ?? '') as String;
          final nom = (data['nom'] ?? '') as String;
          final full = ([prenom, nom].where((s) => s.trim().isNotEmpty))
              .join(' ')
              .trim();
          if (email.isNotEmpty && full.isNotEmpty) {
            _userDisplayNameCache[email] = full;
          }
        }
      }
      _lastUserFetch = DateTime.now();
      // Déclencher un refresh UI (rx assign pour forcer Obx rebuild si nécessaire)
      prelevements.refresh();
      ventes.refresh();
      restitutions.refresh();
      pertes.refresh();
    } catch (_) {
      // Ignore silently; fallback remains email
    } finally {
      _userFetchInProgress = false;
    }
  }

  bool get isAdminRole {
    final r = _session.role ?? '';
    return r == 'Admin' || r == 'Magazinier' || r == 'Gestionnaire Commercial';
  }

  String get effectiveSite => isAdminRole
      ? (selectedSite.value.isNotEmpty
          ? selectedSite.value
          : (_session.site ?? ''))
      : (_session.site ?? '');

  @override
  void onInit() {
    super.onInit();
    if (!isAdminRole) selectedSite.value = _session.site ?? '';
    loadAll();
  }

  Future<void> loadAll({bool forceRefresh = false}) async {
    isLoading.value = true;
    try {
      // 1. Ensure attributions are loaded (populate attribution cache)
      await _commercialService.getLotsAvecCache(forceRefresh: forceRefresh);
      _buildAttributionScope();

      final siteFilter = isAdminRole
          ? (selectedSite.value.isEmpty ? null : selectedSite.value)
          : _session.site;
      final commercialId = isAdminRole ? null : _session.email;

      final futures = await Future.wait([
        _venteService.getPrelevementsAdmin(
            siteFilter: siteFilter,
            forceRefresh: forceRefresh,
            commercialId: commercialId),
        _venteService.getVentes(
            siteFilter: siteFilter,
            forceRefresh: forceRefresh,
            commercialId: commercialId),
        _venteService.getRestitutions(
            siteFilter: siteFilter,
            forceRefresh: forceRefresh,
            commercialId: commercialId),
        _venteService.getPertes(
            siteFilter: siteFilter,
            forceRefresh: forceRefresh,
            commercialId: commercialId),
        _fetchClients(siteFilter: siteFilter, forceRefresh: forceRefresh),
      ]);

      prelevements.assignAll(futures[0] as List<Prelevement>);
      ventes.assignAll(futures[1] as List<Vente>);
      restitutions.assignAll(futures[2] as List<Restitution>);
      pertes.assignAll(futures[3] as List<Perte>);
      clients.assignAll(futures[4] as List<ClientLight>);
      if (!isAdminRole) {
        _applyAttributionFilter();
      }
      // Résolution des noms après filtrage
      await _resolveUserNamesFromData();
      _lastFullLoad = DateTime.now();
    } catch (e) {
      // Ignore, UI montrera message via snackbar si voulu
    } finally {
      isLoading.value = false;
    }
  }

  void _buildAttributionScope() {
    _attributedKeys.clear();
    if (isAdminRole) return; // full access
    final userId = _session.email;
    if (userId == null) return;
    for (final a in _commercialService.attributions) {
      if (a.commercialId == userId) {
        // lotId already unique (constructed previously). Also include fallback composite key
        _attributedKeys.add(a.lotId);
        final composite = '${a.numeroLot}_${a.typeEmballage}_${a.siteOrigine}';
        _attributedKeys.add(composite);
      }
    }
  }

  bool _isAllowedByAttribution(
      {required String numeroLot,
      required String typeEmballage,
      required String site,
      required String lotId}) {
    if (isAdminRole) return true;
    if (_attributedKeys.isEmpty) return false; // no attribution => no access
    final composite = '${numeroLot}_${typeEmballage}_${site}';
    return _attributedKeys.contains(lotId) ||
        _attributedKeys.contains(composite);
  }

  void _applyAttributionFilter() {
    if (isAdminRole) return;
    final site = _session.site ?? '';

    bool produitsAutorises(List produitsDyn) {
      if (produitsDyn.isEmpty) return false;
      // every product must be in scope (strict policy)
      for (final prod in produitsDyn) {
        // dynamic access (ProduitPreleve / ProduitVendu / ProduitRestitue / ProduitPerdu all share numeroLot & typeEmballage)
        final numeroLot = (prod as dynamic).numeroLot as String? ?? '';
        final typeEmballage = (prod as dynamic).typeEmballage as String? ?? '';
        final lotId =
            CommercialUtils.genererIdLot(site, typeEmballage, numeroLot);
        if (!_isAllowedByAttribution(
            numeroLot: numeroLot,
            typeEmballage: typeEmballage,
            site: site,
            lotId: lotId)) {
          return false;
        }
      }
      return true;
    }

    // ⚠️ Nouvelle règle: un commercial voit tous les prélèvements de son site
    // Donc on NE filtre PAS la liste prelevements par attribution.
    ventes.assignAll(ventes.where((v) => produitsAutorises(v.produits)));
    restitutions
        .assignAll(restitutions.where((r) => produitsAutorises(r.produits)));
    pertes.assignAll(pertes.where((p) => produitsAutorises(p.produits)));
  }

  List<T> _applySearch<T>(List<T> source) {
    final q = search.value.trim().toLowerCase();
    if (q.isEmpty) return source;
    return source.where((item) {
      if (item is Vente) {
        return item.clientNom.toLowerCase().contains(q) ||
            item.commercialNom.toLowerCase().contains(q);
      }
      if (item is Prelevement) {
        return item.commercialNom.toLowerCase().contains(q) ||
            item.id.toLowerCase().contains(q);
      }
      if (item is Restitution) {
        return item.commercialNom.toLowerCase().contains(q) ||
            item.motif.toLowerCase().contains(q);
      }
      if (item is Perte) {
        return item.commercialNom.toLowerCase().contains(q) ||
            item.motif.toLowerCase().contains(q);
      }
      return true;
    }).toList();
  }

  List<Prelevement> get filteredPrelevements => _applySearch(prelevements);
  List<Vente> get filteredVentes => _applySearch(ventes);
  List<Restitution> get filteredRestitutions => _applySearch(restitutions);
  List<Perte> get filteredPertes => _applySearch(pertes);
  List<ClientLight> get filteredClients => _applySearch(clients);
}

/// Modèle léger client pour la liste
class ClientLight {
  final String id;
  final String nom;
  final String? nomBoutique;
  final String? telephone;
  final double? latitude;
  final double? longitude;
  final List<String> commercials; // emails des commerciaux liés
  final DateTime? dateCreation;
  ClientLight({
    required this.id,
    required this.nom,
    this.nomBoutique,
    this.telephone,
    this.latitude,
    this.longitude,
    required this.commercials,
    this.dateCreation,
  });
}

extension _ClientFromMap on ClientLight {
  static ClientLight fromFirestore(Map<String, dynamic> data, String id) {
    return ClientLight(
      id: id,
      nom: (data['nomGerant'] ?? data['nom'] ?? data['nomBoutique'] ?? 'Client')
          .toString(),
      nomBoutique: data['nomBoutique']?.toString(),
      telephone: (data['telephone'] ?? data['telephone1'])?.toString(),
      latitude: (data['latitude'] as num?)?.toDouble(),
      longitude: (data['longitude'] as num?)?.toDouble(),
      commercials: _extractCommercials(data),
      dateCreation: (data['dateCreation'] as Timestamp?)?.toDate(),
    );
  }

  static List<String> _extractCommercials(Map<String, dynamic> d) {
    final set = <String>{};
    for (final key in [
      'commercialId',
      'createdBy',
      'commercialEmail',
      'auteur',
    ]) {
      final v = d[key];
      if (v is String && v.isNotEmpty) set.add(v);
    }
    // champs multiples éventuels
    if (d['commerciaux'] is List) {
      for (final c in (d['commerciaux'] as List)) {
        if (c is String && c.isNotEmpty) set.add(c);
      }
    }
    return set.toList();
  }
}

extension _ClientsLoader on EspaceCommercialController {
  Future<List<ClientLight>> _fetchClients({
    String? siteFilter,
    bool forceRefresh = false,
  }) async {
    try {
      final firestore = FirebaseFirestore.instance;
      final List<ClientLight> results = [];
      // Source 1: Collection hiérarchique Vente/{site}/clients si site connu
      if (siteFilter != null && siteFilter.isNotEmpty) {
        final snap = await firestore
            .collection('Vente')
            .doc(siteFilter)
            .collection('clients')
            .limit(500)
            .get();
        for (final doc in snap.docs) {
          results.add(_ClientFromMap.fromFirestore(doc.data(), doc.id));
        }
      }
      // Source 2: Collection racine 'clients' (legacy?) filtrée par site si champ présent
      final snapRoot = await firestore.collection('clients').limit(500).get();
      for (final doc in snapRoot.docs) {
        final data = doc.data();
        if (siteFilter != null && siteFilter.isNotEmpty) {
          final siteDoc = (data['site'] ?? data['siteClient'])?.toString();
          if (siteDoc != null && siteDoc != siteFilter) continue;
        }
        results.add(_ClientFromMap.fromFirestore(data, doc.id));
      }
      // Déduplication par id
      final map = <String, ClientLight>{};
      for (final c in results) {
        map[c.id] = c;
      }
      return map.values.toList();
    } catch (_) {
      return [];
    }
  }
}
